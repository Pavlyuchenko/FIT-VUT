All required functionality described in zadani-2024.pdf is implemented. The program is able to solve the synchronization problem.
